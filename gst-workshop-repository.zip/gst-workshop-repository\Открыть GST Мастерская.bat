@echo off
cd /d "%~dp0"
start "GST Server" cmd /k "npm start"
timeout /t 2 >nul
start "" http://localhost:3000
